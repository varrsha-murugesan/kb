"""
generate_billing_rules.py
==========================
End-to-end runner to generate billing_rules.xlsx (and billing_rules.json)
for Aetna policies in C:\\Payer Policy\\Aetna, exactly matching the format
and structure of C:\\Payer Policy\\Uhc\\billing_rules.xlsx.

Pipeline:
  1. Checks/updates rule_keywords.csv using analyze_keywords.py
  2. Runs extract_rules.py to generate billing_rules.xlsx and billing_rules.json
  3. Displays verification metrics and sheet summaries

Usage:
    python generate_billing_rules.py
"""

import os
import subprocess
import sys


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    input_json = os.path.join(base_dir, "extraction_rules.json")
    keywords_csv = os.path.join(base_dir, "rule_keywords.csv")
    output_xlsx = os.path.join(base_dir, "billing_rules.xlsx")
    output_json = os.path.join(base_dir, "billing_rules.json")
    pdf_dir = os.path.join(base_dir, "aetna_il_payment_policies")

    print("=" * 70)
    print("AETNA BILLING RULES GENERATION PIPELINE")
    print("=" * 70)

    # Step 1: Ensure rule_keywords.csv exists
    if not os.path.exists(keywords_csv):
        print(f"\n[Step 1/2] Mining signal keywords -> {keywords_csv}...")
        cmd_keywords = [
            sys.executable,
            os.path.join(base_dir, "analyze_keywords.py"),
            "--input", input_json,
            "--out", keywords_csv
        ]
        ret = subprocess.run(cmd_keywords, cwd=base_dir)
        if ret.returncode != 0:
            print("Warning: analyze_keywords.py encountered an issue, proceeding with fallback.")
    else:
        print(f"\n[Step 1/2] Signal lexicon found: {keywords_csv}")

    # Step 2: Run extract_rules.py
    print(f"\n[Step 2/2] Extracting billing rules -> {output_xlsx}...")
    cmd_extract = [
        sys.executable,
        os.path.join(base_dir, "extract_rules.py"),
        "--input", input_json,
        "--keywords", keywords_csv,
        "--out", output_xlsx,
        "--json-out", output_json,
        "--pdf-dir", pdf_dir
    ]
    ret = subprocess.run(cmd_extract, cwd=base_dir)
    if ret.returncode != 0:
        print(f"Error executing extract_rules.py (exit code {ret.returncode})", file=sys.stderr)
        sys.exit(ret.returncode)

    print("\n" + "=" * 70)
    print("PIPELINE EXECUTION COMPLETE")
    print(f"Excel Workbook: {output_xlsx}")
    print(f"JSON Output:    {output_json}")
    print("=" * 70)


if __name__ == "__main__":
    main()
